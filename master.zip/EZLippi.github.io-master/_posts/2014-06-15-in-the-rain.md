---
title: 在雨中
date: 2014-06-15 01:05:13 +0800
layout: post
permalink: /blog/2014/06/15/in-the-rain.html
categories:
  - java
tags:
  - Life
  - 生活
---
我的个人博客上线了．